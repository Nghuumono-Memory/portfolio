import flet as ft

def main(page: ft.Page):
    page.title = "Nghuumono's Portfolio"
    page.bgcolor = "#0f172a"
    page.padding = 0
    page.scroll = ft.ScrollMode.AUTO

    # ── HEADER ──────────────────────────────────────────
    header = ft.Container(
        content=ft.Column([
            ft.Text("Nghuumono Ndateelela", size=38, weight="bold", color="white"),
            ft.Text("Mobile App Development Semester Project", size=18, color="#60a5fa"),
            ft.Text("2nd Year | Electrical Engineering | University of Namibia (UNAM)", size=13, color="#475569"),
        ], spacing=6),
        padding=40,
        bgcolor="#0f172a",
    )

    divider = ft.Container(height=3, bgcolor="#1e40af")

    # ── SECTION TITLE ────────────────────────────────────
    def section_title(icon, text):
        return ft.Container(
            content=ft.Row([
                ft.Text(icon, size=26),
                ft.Text(text, size=24, weight="bold", color="white"),
            ], spacing=10),
            padding=20,
        )

    # ── TIMELINE ITEM ────────────────────────────────────
    def timeline_item(month, title, description, icon="📌"):
        return ft.Container(
            content=ft.Row([
                ft.Text(icon, size=24, width=50),
                ft.Container(width=2, height=80, bgcolor="#1e40af"),
                ft.Column([
                    ft.Text(month, size=12, color="#60a5fa", weight="bold"),
                    ft.Text(title, size=17, weight="bold", color="white"),
                    ft.Text(description, size=13, color="#94a3b8"),
                ], spacing=3, expand=True),
            ]),
            padding=10,
        )

    # ── CERTIFICATE CARD ─────────────────────────────────
    def cert_card(number, course_name):
        return ft.Container(
            content=ft.Column([
                ft.Text("🎓", size=30),
                ft.Text(f"Course {number}", size=12, weight="bold", color="#60a5fa"),
                ft.Text(course_name, size=12, color="white"),
                ft.Container(
                    content=ft.Text("✓ Completed", size=11, color="#4ade80"),
                    bgcolor="#052e16",
                    border_radius=20,
                    padding=8,
                ),
            ], horizontal_alignment=ft.CrossAxisAlignment.CENTER, spacing=6),
            width=180,
            height=170,
            bgcolor="#1e293b",
            border_radius=12,
            padding=15,
        )

    # ── ABOUT ────────────────────────────────────────────
    about = ft.Container(
        content=ft.Column([
            ft.Text("About Me", size=24, weight="bold", color="white"),
            ft.Text(
                "My name is Nghuumono Ndateelela, a 2nd year Electrical Engineering student "
                "at the University of Namibia (UNAM). This portfolio documents my activities "
                "and achievements from the Mobile App Development semester project, including "
                "7 completed MATLAB courses with certificates and reports.",
                size=14, color="#94a3b8",
            ),
        ], spacing=10),
        padding=20,
        bgcolor="#111827",
        margin=20,
        border_radius=12,
    )

    # ── TIMELINE ─────────────────────────────────────────
    timeline_section = ft.Column([
        section_title("📅", "Timeline"),
        timeline_item("March 2025", "Project Kickoff", "Started the Mobile App Development semester project.", "🚀"),
        timeline_item("April 2025", "MATLAB Courses Begin", "Started working through the required MATLAB online courses.", "📚"),
        timeline_item("April 2025", "MATLAB Onramp", "Completed the foundational MATLAB Onramp course.", "✅"),
        timeline_item("April 2025", "Calculations with Vectors & Matrices", "Learned to perform calculations using vectors and matrices.", "🧮"),
        timeline_item("April 2025", "Make and Manipulate Matrices", "Practiced creating and manipulating matrices in MATLAB.", "📐"),
        timeline_item("April 2025", "Explore Data with MATLAB Plots", "Learned data visualization and plotting techniques.", "📊"),
        timeline_item("April 2025", "The How and Why of Writing Functions", "Studied function writing principles and best practices.", "🔧"),
        timeline_item("April 2025", "Machine Learning Onramp", "Completed introduction to Machine Learning concepts.", "🤖"),
        timeline_item("April 2025", "Simulink Onramp", "Completed the Simulink simulation environment course.", "⚙️"),
        timeline_item("May 2025", "Portfolio Development", "Built this student portfolio using Python Flet.", "💻"),
    ])

    # ── CERTIFICATES ─────────────────────────────────────
    certs_section = ft.Column([
        section_title("🎓", "MATLAB Certificates"),
        ft.Container(
            content=ft.Text(
                "7 courses completed with certificates and reports",
                size=13, color="#94a3b8",
            ),
            padding=20,
        ),
        ft.Container(
            content=ft.Row([
                cert_card(1, "MATLAB\nOnramp"),
                cert_card(2, "Machine Learning\nOnramp"),
                cert_card(3, "How & Why of\nWriting Functions"),
                cert_card(4, "Calculations with\nVectors & Matrices"),
                cert_card(5, "Simulink\nOnramp"),
                cert_card(6, "Make & Manipulate\nMatrices"),
                cert_card(7, "Explore Data with\nMATLAB Plots"),
            ], wrap=True, spacing=12, run_spacing=12),
            padding=20,
        )
    ])

    # ── FOOTER ───────────────────────────────────────────
    footer = ft.Container(
        content=ft.Column([
            ft.Divider(color="#1e293b"),
            ft.Text(
                "Nghuumono Ndateelela | Electrical Engineering | UNAM | 2025",
                size=12, color="#475569",
            ),
        ], horizontal_alignment=ft.CrossAxisAlignment.CENTER, spacing=4),
        padding=20,
    )

    page.add(header, divider, about, timeline_section, certs_section, footer)

ft.app(target=main)